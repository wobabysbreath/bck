#include <cv.hpp>
#include <cxcore.hpp>
#include <highgui.h>
#include <iostream>
#include <stdio.h>
#include <cvaux.hpp>
 
using namespace cv;

int main( int argc, char** argv )
{
  //声明IplImage指针
  IplImage* frame = NULL;

 //获取摄像头
  CvCapture* pCapture = cvCreateCameraCapture(-1);
 
  //创建窗口
  cvNamedWindow("video", 1);
  
  //显示视屏
  while(1)
  {
      IplImage* LogPolar_frame ; 
      frame=cvQueryFrame( pCapture );
      LogPolar_frame = cvCreateImage(cvSize(frame->width,frame->height), IPL_DEPTH_8U, 1);
      cvCvtColor( frame, LogPolar_frame, CV_BGR2GRAY );
      LogPolar_frame->origin=0;
      if(!frame)break;
      cvShowImage("video",LogPolar_frame);
      cvWaitKey(33);
     // if(c==27)break;
  }
  cvReleaseCapture(&pCapture);
  cvDestroyWindow("video");
}
